#!/usr/bin/env python
# coding: utf-8

# In[1]:



profane=[
        "เหี้ย", 
        "ควย", 
        "ค ว ย", 
        "ค วย", 
        "ชาติหมา", 
        "เหี้ ย", 
        "คว ย",  
        "เย็ด", 
        "อีดอก", 
        "อีสัตว์", 
        "อีเห็ด", 
        "หมอย", 
        "แตด", 
        "ไอ้สัตว์", 
        "แม่มึงตาย", 
        "พ่อมึงตาย", 
        "แม่มึง", 
        "พ่อมึง", 
        "อีหอย", 
        "เงี่ยน", 
        "ไอ้ควาย", 
        "ไอ้ห่า", 
        "อีสัด", 
        "ไอ้สัด", 
        "ไอสัด", 
        "ไอสัตว์", 
        "มารดามึงตาย", 
        "อีร่าน", 
        "แม่งตาย", 
        "ไอ้สัส", 
        "อีสัส", 
        "พ่องตาย", 
        "เยด", 
        "ไอ่สัตว์", 
        "ไอ่สัด", 
        "ไอ่ห่า", 
        "อิร่าน", 
        "กูร่าน",
        "อีเหี้ย",
        "อีหี",
        "มึงร่าน",
            "หี", 
        "หมอย"
    ]


# In[ ]:


bad=[]
lenbad=[]
s=''
aa=[]
def findprofane(x):
    for i,v in enumerate(profane):
        result = x.find(v)
        if result != -1:
            bad.append(result)
            lenbad.append(len(v))
    return censorth(bad,lenbad,x,len(lenbad))

def censorth(bad,lenbad,x,n):
    s=''
    if n == 0:
        aa.append(s)
        return finalth(aa,lenbad)
    s = x[:bad[n-1]] + '*'*lenbad[n-1] + x[bad[n-1]+lenbad[n-1]:]
    aa.append(s)
    return censorth(bad,lenbad,s,n-1)

def finalth(aa,lenbad):
    return aa[len(lenbad)-1]


# In[ ]:


def chkTH_type(zondict,x):
    result=''
    typezon=[]
    redlist=['profane','profane2','unique_lm']
    yellowlist=['competitor','unique_sexual']
    greenlist=['none_unique_lm','users_questions','potential_sexual','mis','political','ref_royalty','unique_political']
    for i,v in zondict.items():    
        for idx,val in enumerate(v):
            result = x.find(val)
            if result !=-1:
                typezon.append(i)


    #print("ALL TYPE THAT EXISTS HERE:",typezon)
    S1 = set(redlist)
    S2 = set(typezon)
    S3 = set(yellowlist)
    S4 = set(greenlist)
    if S1.intersection(S2):
        #hide - alertflag = 2
        flag =2
        #print(flag)
    elif S3.intersection(S2):
        flag =3
        #print(flag)
    elif S4.intersection(S2):
        flag =1
        #print(flag)    
    else:
        flag = 0
        #print(flag)
    return flag

#chkTH_type(zondict,x) #where x = string
